#!/bin/bash
playwright install
python3 main.py